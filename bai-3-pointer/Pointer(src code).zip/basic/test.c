#include <stdio.h>
int main(){
    return 0;
}

int* var = 10; // 0 hoac 1

//0b 00000000 (MSB) 00000000 00000000 00001010 (LSB)
//      0x04        0x03        0x02     0x01

/* 
    double -> 8 byte
    char -> 1 byte
    float/int -> 4 byte


*/
/* 
    - khai báo và sử dụng con trỏ
    - kích thước, và kiểu dữ liệu của con trỏ
    - endian little/big 
    - con trỏ thao tác trên mảng
    - truyền tham trị / con trỏ
*/


