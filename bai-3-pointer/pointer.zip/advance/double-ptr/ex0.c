#include <stdio.h>
/* 
   "temp : 23
    humi : 45
    device : stm32/esp32/arduino
    sensor : dht11"
*/

int value; 
char str[12];
void parsestring();
void parsenumber();
int main()
{
    int value = 42;
    int *ptr1 = &value;  // Con trỏ thường trỏ đến một biến
    int **ptr2 = &ptr1;  // Con trỏ đến con trỏ

    /*
        **ptr2 = &ptr1
        ptr2 = &ptr1;
        *ptr2 = ptr1 = *(&value);
        **ptr2 = *ptr1 = value
    */

    printf("address of value: %p\n", &value);
    printf("value of ptr1: %p\n", ptr1);

    printf("address of ptr1: %p\n", &ptr1);
    printf("value of ptr2: %p\n", ptr2);

    printf("dereference ptr2 first time: %p\n", *ptr2); 
    printf("dereference ptr2 second time: %d\n", **ptr2);

    return 0;
}

