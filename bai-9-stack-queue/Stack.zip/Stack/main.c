#include "stack.h"

int main(){
    Stack stack;
    int size = 5;
    STACK_LOG(NULL,Stack_Init(&stack,size));
    
    printf("push process\n");
    for(int i = 0 ; i < size ; i++){
        STACK_LOG(&stack.items[stack.top], Stack_Push(&stack, i));
    }

    printf("pop process\n");
    for(int i = 0 ; i < size ; i++){
        static int popdata,topdata;
        StackStatus status = STACK_HANDLE_OK;
        STACK_LOG(&topdata,Stack_Top(&stack,&topdata));
        //STACK_LOG(&stack.items[stack.top],status);
        Stack_Pop(&stack,&popdata);
    }

    STACK_LOG(NULL,Stack_Free(&stack));    
    return 0;
}