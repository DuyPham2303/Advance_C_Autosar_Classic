#ifndef EX_H
#define EX_H
void demo();
#endif