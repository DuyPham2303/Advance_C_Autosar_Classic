#include "ex.h"
#include <stdio.h>
void demo(){
    printf("this is ex\n");
}